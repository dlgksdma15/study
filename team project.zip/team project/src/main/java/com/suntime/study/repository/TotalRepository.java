package com.suntime.study.repository;

import com.suntime.study.entity.TotalEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TotalRepository extends JpaRepository<TotalEntity, Long> {
}
